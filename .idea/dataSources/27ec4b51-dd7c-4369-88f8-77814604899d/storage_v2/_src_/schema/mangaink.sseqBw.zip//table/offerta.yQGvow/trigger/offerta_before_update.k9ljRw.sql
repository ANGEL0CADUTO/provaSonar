create definer = root@localhost trigger offerta_BEFORE_UPDATE
    before update
    on offerta
    for each row
BEGIN
    IF NEW.statoOfferta = 3 THEN
        -- 1. Salvare annuncio.copiaMangaID nella variabile
        SELECT annuncio.copiaMangaID INTO @var_copiaMangaID
        FROM annuncio
        WHERE annuncio.idAnnuncio = NEW.annuncioID;

        -- 2. Inserire nuova tupla nella tabella Transazioni utilizzando VALUES
        INSERT INTO transazione (annuncioID, prezzoVenduto, dataVendita, copiaMangaID, utenteCompratoreID)
        VALUES (NEW.annuncioID, NEW.offertaPrezzo, NOW(), @var_copiaMangaID, NEW.utenteOfferenteID);
        
        -- 5. Ottenere l'ID dell'ultima transazione inserita(PROBABILMENTE INUTILE)
        SELECT LAST_INSERT_ID() INTO @var_transactionID;
        
        -- 3. Aggiornamento dataVendita in copiaManga
        UPDATE copiamanga
        SET dataVendita = NOW(), statoCopiaManga = 3
        WHERE idCopiaManga = @var_copiaMangaID;

        -- 4. Aggiornamento stato annuncio a venduto
        UPDATE annuncio
        SET statoAnnuncio = 3
        WHERE idAnnuncio = NEW.annuncioID;
        
        SET NEW.transazioneID = @var_transactionID;


        

    END IF;
END;

